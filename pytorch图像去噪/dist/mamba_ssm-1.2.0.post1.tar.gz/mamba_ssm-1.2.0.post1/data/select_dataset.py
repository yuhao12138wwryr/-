

'''
# --------------------------------------------
# select dataset
# --------------------------------------------
# Kai Zhang (github: https://github.com/cszn)
# --------------------------------------------
'''

#取出drnet后使用数据dataset_drnet
def define_Dataset(dataset_opt):
    dataset_type = dataset_opt['dataset_type'].lower()#取出drnet。.lower() 是一个字符串方法，它将字符串中的所有字符转换为小写形式。

    if dataset_type in ['drnet', 'denoising']:
        from data.dataset_drnet import DatasetDRNet as D
    elif dataset_type in ['sidd', 'denoising']:
        from data.dataset_sidd import DatasetSIDD as D
    elif dataset_type in ['drnet_pepper', 'denoising']:
        from data.dataset_drnet_pepper import DatasetDRNet_SP as D
    elif dataset_type in ['drnet_possion', 'denoising']:
        from data.dataset_drnet_possion import DatasetDRNet_Possion as D
    else:
        raise NotImplementedError('Dataset [{:s}] is not found.'.format(dataset_type))

    dataset = D(dataset_opt)
    print('Dataset [{:s} - {:s}] is created.'.format(dataset.__class__.__name__, dataset_opt['name']))
    return dataset
